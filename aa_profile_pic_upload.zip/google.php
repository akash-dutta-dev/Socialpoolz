<?php

require'google_login.php';
echo "<button><a href='$auth_url'>Login Through Google </a></button>";

