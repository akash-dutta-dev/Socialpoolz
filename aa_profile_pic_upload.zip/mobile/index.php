<!DOCTYPE html>
<html>
<head>
<title>Welcome to SocialPoolz</title>
</head>
<body>

<h1>The website is not optomized for mobile and we are working on it. Please use a desktop to view the content.</h1>


</body>
</html>