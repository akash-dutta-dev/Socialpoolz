<?php
include("header.php");
?>
        <div class="header_cover" style="width:100%;height:50px;">
        </div>

        <div class='about_page_cover'>
			<div  class="question_tabcontent about_page">
				<h2>Our Aim</h2>
				Our Aim is to provide enormous knowledge to those people who seek for it.
				Knowledge is something which has a beginning but no end.
				Reading is something which our World specially need, rather than scrolling some unnecessary post.
				The only source of knowledge is experience, so we provide experienced expert who work 24x7 to provide relevant answer to your precious questions.
				We would like us to be called Knowledge Resourcing website rather than Social Networking website.
				
				<img src='assets/images/about_page_pic1.jpg'>
				
				<br>
				<br>
				
				<h2>Our Message to New Users</h2>
				First of all we would like to thank you for visiting SocialPoolz.
				We always look forward to serve you better.
				Feel free to ask any question here, because we believe <b>Knowledge</b> is having the right answer but, <b>Intelligence</b> is asking the the right question.
				Always take a step forward by asking a question.<br>
				As <b>ASK</b> stands for<br>
				<i>A - Always </i><br>
				<i>S - Seek </i><br>
				<i>K - Knowledge </i><br>
				
				<br>
				<br>
				
				<h2>What to do in SocialPoolz?</h2>
				Always search for new topic or any interesting article. 
				Ask simple question in interesting way.
				Dont ask questions like <br><i>Q:- In which year did Akbar died? OR <br>Q:-What is the population of India?</i><br>
				Because you can easily get those in Google,<br>
				Instead ask questions like, <br>
				<i>Q:-What is the effect of demonetization to common people? OR <br>
					Q:-What is going to be our Education System in next 10 years?</i>
				
				<br>
				<br>
			</div>
		</div>
			
        

       
    </body>
</html>
  
    
     
